# Thêm hai thư viện numpy cho đại số tuyến tính và matplotlib cho việc vẽ hình
from __future__ import division, print_function, unicode_literals
import numpy as np
import matplotlib.pyplot as plt

# Khai báo và biểu diễn dữ liệu trên một đồ thị
# Chiều cao (cm) -H
H = np.array([[147, 150, 153, 155, 158, 160, 163, 165, 168, 170, 173, 175, 178, 180, 183]]).T
# Cân nặng (kg) -W
W = np.array([[49, 50, 51, 52, 54, 56, 58, 59, 60, 62, 63, 64, 66, 67, 68]]).T
# Hiển thị dũ liệu trên đồ thị
plt.plot(H, W, 'ro')
plt.axis([140, 190, 45, 75])
plt.xlabel('Chiều cao (cm)')
plt.ylabel('Cân nặng (kg)')
#plt.show()

#Tính toán các hệ số a và b dựa vào công thức giả nghịch đảo, điểm tối ưu của bài toán Linear Regression.
 #Building Xbar
one = np.ones((H.shape[0], 1))
Hbar = np.concatenate((one, W), axis = 1)
#Calculating weights of the fitting line
A = np.dot(Hbar.T, Hbar)
b = np.dot(Hbar.T, W)
w = np.dot(np.linalg.pinv(A), b) #Hàm tính nghịch đảo của A; pinv là từ viết tắt của pseudo inverse
print('w = ', w)
#Preparing the fitting line
w_0 = w[0][0]
w_1 = w[1][0]
x0 = np.linspace(145, 185, 2)
y0 = w_0 + w_1*x0
#Drawing the fitting line
plt.plot(H.T, W.T, 'ro')     # data 
plt.plot(x0, y0)               # the fitting line
plt.axis([140, 190, 45, 75])
plt.xlabel('Chiều cao (cm)')
plt.ylabel('Cân nặng (kg)')
plt.show()