#Import thư viện cần thiết.
#Thư viện sử dụng để giải quyết bài toán này là sklearn.naive_bayes
from __future__ import print_function
from sklearn.naive_bayes import BernoulliNB
import numpy as np 

#Tạo data
#Do chúng ta sử dụng mô hình Bernoulli Naive Bayes nên các giá trị khác không sẽ đều đưa về 1. 
d1 = [1, 1, 1, 0, 0, 0, 0, 0, 0]
d2 = [1, 1, 0, 1, 1, 0, 0, 0, 0]
d3 = [0, 1, 0, 0, 1, 1, 0, 0, 0]
d4 = [0, 1, 0, 0, 0, 0, 1, 1, 1]

#Train data
train_data = np.array([d1, d2, d3, d4])
label = np.array(['B', 'B', 'B', 'N']) #0-B, 1-N

#Test data
d5 = np.array([[1, 0, 0, 1, 0, 0, 0, 1, 0]])
d6 = np.array([[0, 1, 0, 0, 0, 0, 0, 1, 1]])

#Gọi hàm BernoulliNB của thư viện sklearn
clf = BernoulliNB()

#Training
clf.fit(train_data, label)

#Test
print('Predicting class of d5:', str(clf.predict(d5)[0]))
print('Probability of d6 in each class:', clf.predict_proba(d6))
