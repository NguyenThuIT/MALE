from cvxopt import matrix, solvers

#trong bài toán, cần tìm giá trị lón nhất nên ta phải đổi hàm mục tiêu về dạng -5x - 3y.
#chín vì vậy, c = matrix(ơ-5., -3.])
c = matrix([-5., -3.])
#hàm matrix nhận đầu vào là một list, list này thể hiện một vector cột.
G = matrix([[1., 2., 1., -1., 0.], [1., 1., 4., 0., -1.]])
h = matrix([10., 16., 32., 0., 0.])

#hàm solvers.l của cvxopt giải bài toán
solvers.options['show_progress'] = False
sol = solvers.lp(c, G, h)

print('Solution"')
print(sol['x'])