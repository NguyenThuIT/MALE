#Import các thư viên cần thiết
#Bài toán này ta sẽ giải quyết với sklearn là chính
from __future__ import print_function
from sklearn.naive_bayes import MultinomialNB
import numpy as np

#Tạo data
d1 = [2, 1, 1, 0, 0, 0, 0, 0, 0]
d2 = [1, 1, 0, 1, 1, 0, 0, 0, 0]
d3 = [0, 1, 0, 0, 1, 1, 0, 0, 0]
d4 = [0, 1, 0, 0, 0, 0, 1, 1, 1]

#Train data
train_data = np.array([d1, d2, d3, d4])
label = np.array(['B', 'B', 'B', 'N']) 

#Test data
d5 = np.array([[2, 0, 0, 1, 0, 0, 0, 1, 0]])
d6 = np.array([[0, 1, 0, 0, 0, 0, 0, 1, 1]])

#Gọi hàm MultinomialNB của sklearn_naive_bayes
clf = MultinomialNB()

#Training
clf.fit(train_data, label)

#Test
print('Predicting class of d5:', str(clf.predict(d5)[0]))
print('Probability of d6 in each class:', clf.predict_proba(d6))